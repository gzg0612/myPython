from distutils.core import setup

setup(
		name    = 'debug',
		version = '1.0.0',
		py_modules = ['debug'],
		author = 'Andrew',
		author_email = 'gzg0612@qq.com',
		url			= '',
		description = 'debug',
	  )
